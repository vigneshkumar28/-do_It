a = [1, 2, 3, 4, 5]

print len(a)

print a[0: 2]

print a[:5]
print a[0:]
