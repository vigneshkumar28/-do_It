stuff = 'Hello\nWorld!'
print(stuff)

print(len(stuff))
# \n character is counted as one character