stuff = dict()
stuff['money'] = 1
stuff['apples'] = 0

stuff['google'] = 2
print stuff