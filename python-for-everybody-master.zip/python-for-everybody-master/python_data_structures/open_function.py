handle = open(filename, mode)
# 1. Name of file
# 2. How to read: 'r' to read or 'w' to write

# Handle connects the primary and secondary storage
# Simple: name of file must be same folder as the python code
