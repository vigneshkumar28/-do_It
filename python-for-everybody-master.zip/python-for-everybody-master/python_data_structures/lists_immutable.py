fruit = 'Banana'
fruit[0] = 'b'
# This gives an error as you can't change a string

new_fruit = fruit.upper()
print new_fruit
# You can create a new variable