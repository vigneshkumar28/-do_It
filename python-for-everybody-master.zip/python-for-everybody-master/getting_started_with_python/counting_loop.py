count = 0
print('Before', count)

for thing in [9, 41, 12, 3, 74, 15]:
    count += 1
    # zork = zork + 1
    print(count, thing)

print('After', count)
