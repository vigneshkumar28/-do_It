inp = input('Europe floor? ')
# input() runs first, then it stores the value into variable inp
usf = int(inp) + 1
print("US floor", usf)
