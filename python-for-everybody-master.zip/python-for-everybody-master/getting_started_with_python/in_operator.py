fruit = 'baanana'

if 'n' in fruit:
    print('Found it!')

if "m" in fruit:
    print('Found it!')
