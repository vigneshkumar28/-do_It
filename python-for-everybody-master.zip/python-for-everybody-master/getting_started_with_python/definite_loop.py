for i in [5, 4, 3, 2, 1]:
    print i
    # Prints 5, 4, 3, 2, 1 using an iteration variable in a finite loop

print 'Blastoff!'


