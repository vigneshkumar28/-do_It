n = 0
while n > 0:
    print 'Zero trip loop'

print 'Zero trip loop!'
