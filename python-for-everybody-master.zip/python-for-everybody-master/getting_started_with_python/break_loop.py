while True:
    line = input('> ')
    if line == 'done':
        break
        # Breaks out of loop if done
        # Otherwise, the loop continues and prints line.
    print(line)
print('Done!')