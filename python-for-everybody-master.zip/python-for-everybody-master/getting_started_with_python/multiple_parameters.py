def addtwo(a, b):
    added = a + b
    return added
# a,b are parameters

x = addtwo(3, 5)
print(x)
# 3,5 are arguments

