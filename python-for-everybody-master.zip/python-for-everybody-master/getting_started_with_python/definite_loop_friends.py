friends = ['Joseph', 'Glenn', 'Sally']

for friend in friends:
    print('Happy New Year', friend)

print('Done!')

# Iteration variable friend
# Friend changes each time through the loop