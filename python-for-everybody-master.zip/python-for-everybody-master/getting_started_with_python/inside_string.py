fruit = 'banana'
# Character starts from 0
letter = fruit[1]
print letter

n = 3
letter_2 = fruit[n - 1]
print letter_2

print len(fruit)
# Counts the number of characters
# 6
# len() is an in-built function