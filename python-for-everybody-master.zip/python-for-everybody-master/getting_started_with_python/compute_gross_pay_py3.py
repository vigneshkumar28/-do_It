hrs = input('Enter Hours: ')
hrs = float(hrs)

hourly_rate = input('Enter Hourly Rate: ')
hourly_rate = float(hourly_rate)

gross_pay = hourly_rate * hrs
print("Gross pay:", gross_pay)
