nam = raw_input('Who are you?')
print 'Welcome', nam
