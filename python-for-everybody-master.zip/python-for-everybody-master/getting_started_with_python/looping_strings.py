fruit = 'banana'

index = 0

while index < len(fruit):
    letter = fruit[index]
    print(index, letter)
    index += 1

print (" ")

for letter in fruit:
    print(letter)
