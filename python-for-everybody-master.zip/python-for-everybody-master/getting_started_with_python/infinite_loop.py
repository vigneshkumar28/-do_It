n = 5
while n > 0:
    print 'Lather'
    print 'Rinse'

print 'Dry off!'

