nam = input('Who are you?')
print('Welcome', nam)

name = raw_input('Enter your name')
print "Hello " + name
