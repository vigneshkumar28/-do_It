word = 'banana'

for letter in word:
    print(letter)
