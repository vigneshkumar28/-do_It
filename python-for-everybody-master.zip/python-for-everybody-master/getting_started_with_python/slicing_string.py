s = 'Monty Python'
print(s[0: 4])
# Up to but not including

print(s[6: 7])

print(s[6: 20])
# Only prints 6 to 11

print(s[:2])
# Up to but not including

print(s[8:])
# From 8 until end

print(s[:])
# Prints all

