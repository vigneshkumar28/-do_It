print('Before')

for value in [9, 41, 12, 74, 15]:
    if value > 20:
        print('Large number', value)

print('After')