# Increase indent for "if" or "for" statement

# Maintain indent to indicate scope (which lines affected by if/for statement)

# Reduce indent to indicate end of the block (if/for statement)

# Blank lines ignored

# Comments ignored
