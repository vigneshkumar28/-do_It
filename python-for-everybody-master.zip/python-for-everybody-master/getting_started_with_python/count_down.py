n = 6
while n > 0:
    n -= 1  # augmented assignment & iteration variable
    print(n)
print('Blastoff!')
