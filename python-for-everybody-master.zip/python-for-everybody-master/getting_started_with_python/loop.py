n = 5
while n > 0:
    print n
    n -= 1
    # n = n - 1
print 'Blastoff!'
print n

# Results
# 5 --> print 5 then subtract 1 = 4
# 4 --> print 4 then subtract 1 = 3
# 3
# 2
# 1 --> print 1 then subtract 1 = 0
# Blastoff
# 0 --> result of last subtraction

# Loops (repeated steps) have iteration variables, n
# Iteration variable changes each time through a loop
# Often go through a sequence of numbers
