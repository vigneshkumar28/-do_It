l = 5

for i in range(l):
    print "test"